<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.gmail.com'; // o tu servidor SMTP
$config['smtp_port'] = 587;
$config['smtp_user'] = 'solanorojasdavid@gmail.com';
$config['smtp_pass'] = 'gteu emhe hzxs cpha';
$config['smtp_crypto'] = 'tls';
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['wordwrap'] = TRUE;
$config['newline'] = "\r\n";
$config['smtp_debug'] = 2; 